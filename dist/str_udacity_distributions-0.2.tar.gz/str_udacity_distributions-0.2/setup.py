from setuptools import setup

setup(name='str_udacity_distributions', 
      version='0.2',
      description='Gaussian distributions',
      packages=['str_udacity_distributions'],
      author='Torin Rettig',
      author_email='torin.rettig@gmail.com',
      url='https://github.com/torinrettig/udacity_distributions',      
      zip_safe=False)
